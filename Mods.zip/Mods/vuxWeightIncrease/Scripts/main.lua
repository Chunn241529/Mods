NotifyOnNewObject("/Script/Pal.PalGameSetting", function(PalGameSetting)
	PalGameSetting.DefaultMaxInventoryWeight = 1000
	PalGameSetting.AddMaxInventoryWeightPerStatusPoint = 260
end)